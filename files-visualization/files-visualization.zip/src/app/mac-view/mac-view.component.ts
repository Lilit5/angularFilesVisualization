import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mac-view',
  templateUrl: './mac-view.component.html',
  styleUrls: ['./mac-view.component.css']
})
export class MacViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
